import sys
from unittest.case import (
    addModuleCleanup,
    FunctionTestCase,
    SkipTest,
    skip,
    skipIf,
    skipUnless,
    expectedFailure,
)
from unittest.case import TestCase as TestCaseSrc
from unittest.case import _Outcome

class Outcome(_Outcome):
    def __init__(self, result=None):
        super().__init__(result)
        self.error_stages = []  # 失败发生在的步骤：_miniClassSetUp, _miniSetUp, _miniTearDown, setUpClass, tearDownClass, setUp, tearDown, testMethod


# 重写testcase
class TestCase(TestCaseSrc):
    def _callSetUp(self):
        # self._miniSetUp()
        self.setUp()

    def _miniSetUp(self):
        pass

    def _callTearDown(self):
        # self._miniTearDown()
        self.tearDown()

    def _miniTearDown(self):
        pass

    def run(self, result=None):
        orig_result = result
        if result is None:
            result = self.defaultTestResult()
            startTestRun = getattr(result, "startTestRun", None)
            if startTestRun is not None:
                startTestRun()

        result.startTest(self)

        testMethod = getattr(self, self._testMethodName)
        if getattr(self.__class__, "__unittest_skip__", False) or getattr(
            testMethod, "__unittest_skip__", False
        ):
            # If the class or method was skipped.
            try:
                skip_why = getattr(self.__class__, "__unittest_skip_why__", "") or getattr(
                    testMethod, "__unittest_skip_why__", ""
                )
                self._addSkip(result, self, skip_why)
            finally:
                result.stopTest(self)
            return

        expecting_failure_method = getattr(testMethod, "__unittest_expecting_failure__", False)
        expecting_failure_class = getattr(self, "__unittest_expecting_failure__", False)
        expecting_failure = expecting_failure_class or expecting_failure_method
        outcome = Outcome(result)
        try:
            self._outcome = outcome
            # if getattr(self.__class__, "__minitest_class_setup_failure__", False):
            #     exc_info = getattr(
            #         self.__class__,
            #         "__minitest_class_setup_failure_why__",
            #         sys.exc_info(),
            #     )
            #     self._outcome.success = False
            #     self._outcome.errors.append((self, exc_info))
            #     self._outcome.error_stages.append("_miniClassSetUp")
            #     result.addError(self, exc_info)
            #     return result

            with outcome.testPartExecutor(self):
                self._miniSetUp()
            if outcome.success:
                with outcome.testPartExecutor(self):
                    self._callSetUp()
                if outcome.success:
                    outcome.expecting_failure = expecting_failure
                    with outcome.testPartExecutor(self, isTest=True):
                        self._callTestMethod(testMethod)
                    if expecting_failure == outcome.success:
                        self._outcome.error_stages.append("testMethod")
                    outcome.expecting_failure = False
                    with outcome.testPartExecutor(self):
                        self._callTearDown()
                    if not outcome.success:
                        self._outcome.error_stages.append("tearDown")
                else:
                    self._outcome.error_stages.append("setUp")
            else:
                self._outcome.error_stages.append("_miniSetUp")
            outcome.expecting_failure = False
            with outcome.testPartExecutor(self):
                self._miniTearDown()
            if not outcome.success:
                self._outcome.error_stages.append("_miniTearDown")

            self.doCleanups()
            for test, reason in outcome.skipped:
                self._addSkip(result, test, reason)
            self._feedErrorsToResult(result, outcome.errors)
            if outcome.success:
                if expecting_failure:
                    if outcome.expectedFailure:
                        self._addExpectedFailure(result, outcome.expectedFailure)
                    else:
                        self._addUnexpectedSuccess(result)
                else:
                    result.addSuccess(self)
            return result
        finally:
            result.stopTest(self)
            if orig_result is None:
                stopTestRun = getattr(result, "stopTestRun", None)
                if stopTestRun is not None:
                    stopTestRun()

            # explicitly break reference cycles:
            # outcome.errors -> frame -> outcome -> outcome.errors
            # outcome.expectedFailure -> frame -> outcome -> outcome.expectedFailure
            outcome.errors.clear()
            outcome.expectedFailure = None

            # clear the outcome, no more needed
            self._outcome = None
