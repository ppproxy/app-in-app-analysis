#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
"""
Author:         yopofeng
Filename:       utils.py
Create time:    2021/9/24 21:21
Description:

"""
import time
from functools import wraps
import typing
import platform
import re


def timeout(duration):
    """
    重试超时装饰器，在超时之前会每隔一秒重试一次
    注意：被修饰的函数必须要有非空返回，这是重试终止的条件！！！
    :param duration: seconds
    :return:
    """

    def spin_until_true(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            timeout = time.time() + duration
            r = func(*args, **kwargs)
            time.sleep(1)
            while not (r or timeout < time.time()):
                r = func(*args, **kwargs)
                time.sleep(1)
            return r

        return wrapper

    return spin_until_true


_platform = platform.platform()
isWindows = "Windows" in _platform
isMacOS = "Darwin" in _platform or "macOS" in _platform

class Version(object):
    def __init__(self, version: str) -> None:
        if (version in ("latest", "dev")):
            self.version = "latest"
        elif re.match(r"^[0-9\.]+$", version or ""):
            self.version = version
        else:
            raise ValueError(f"{version} format not collect")

    def __str__(self) -> str:
        return self.version

    def __comp_version(self, a: str, b: str) -> int:
        """
        description: 对比基础库版本
        param {*} self
        param {str} a
        param {str} b
        return {int} 1 if a > b, 0 if a == b ,-1 if a < b
        """
        latest = ("latest", "dev")  # latest, dev版本看作是最大的版本号
        if a in latest:
            return 0 if b in latest else 1
        if b in latest:
            return 0 if a in latest else 1
        i = 0
        a = a.split(".")
        b = b.split(".")
        while i < len(a) and i < len(b):
            if int(a[i]) > int(b[i]):
                return 1
            elif int(a[i]) < int(b[i]):
                return -1
            i += 1
        return 0

    def __lt__(self, version):
        if isinstance(version, str):
            version = Version(version)
        if self.__comp_version(self.version, version.version) == -1:
            return True
        return False

    def __le__(self, version):
        if isinstance(version, str):
            version = Version(version)
        if self.__comp_version(self.version, version.version) != 1:
            return True
        return False

    def __eq__(self, version):
        if isinstance(version, str):
            version = Version(version)
        return self.version == version.version
